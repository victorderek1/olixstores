---
title: Door closed fill
layout: icon
categories:
  - Real world
tags:
  - door
  - logout
  - signout
---
