---
title: Arrow down-left
categories:
  - Arrows
tags:
  - arrow
---
