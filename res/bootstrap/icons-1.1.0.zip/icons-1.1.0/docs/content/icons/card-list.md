---
title: Card list
categories:
  - Files and folders
tags:
  - note
  - card
  - notecard
---
