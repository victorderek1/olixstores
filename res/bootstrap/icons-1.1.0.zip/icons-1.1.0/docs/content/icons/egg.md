---
title: Egg
categories:
  - Real world
tags:
  - food
---
