---
title: Briefcase fill
categories:
  - Real world
tags:
  - business
---
